def get_inputs():
    print("Enter the Free Cash Flow (in Rs. crores):")
    free_cash_flow = float(input())

    print("Enter the Market Capitalisation (in Rs. crores):")
    market_cap = float(input())

    print("Enter the Terminal Growth Rate (as a decimal, e.g., 0.02 for 2%):")
    terminal_growth_rate = float(input())

    print("Enter the Expected Growth Rate over the next five years (as a decimal):")
    growth_rate = float(input())

    print("Enter the Discount Rate (as a decimal, e.g., 0.1 for 10%):")
    discount_rate = float(input())

    return free_cash_flow, market_cap, terminal_growth_rate, growth_rate, discount_rate

def calculate_multiplier(free_cash_flow, market_cap):
    return market_cap / free_cash_flow

def calculate_future_value(free_cash_flow, growth_rate):
    future_value = free_cash_flow * (1 + growth_rate)**5
    return future_value

def calculate_terminal_value(future_value, terminal_growth_rate):
    terminal_value = future_value * (1 + terminal_growth_rate)
    return terminal_value

def calculate_present_value(future_value, terminal_value, discount_rate):
    present_value = (future_value + terminal_value) / (1 + discount_rate)**6
    return present_value

def compare_values(free_cash_flow, present_value):
    difference = present_value - free_cash_flow
    percentage_difference = (difference / free_cash_flow) * 100
    if present_value > free_cash_flow:
        print("Margin of Safety.")
    else:
        print("No Margin of Safety.")
    return percentage_difference

def calculate_implied_growth_rate(free_cash_flow, market_cap, discount_rate, terminal_growth_rate):
    implied_growth_rate = (market_cap / free_cash_flow - 1) * (discount_rate - terminal_growth_rate)
    return implied_growth_rate

def main():
    free_cash_flow, market_cap, terminal_growth_rate, growth_rate, discount_rate = get_inputs()

    current_multiplier = calculate_multiplier(free_cash_flow, market_cap)
    print("Current Market Cap to Free Cash Flow Multiplier:", current_multiplier)

    future_value = calculate_future_value(free_cash_flow, growth_rate)
    terminal_value = calculate_terminal_value(future_value, terminal_growth_rate)

    present_value = calculate_present_value(future_value, terminal_value, discount_rate)

    print("Calculated Present Value:", present_value)

    percentage_difference = compare_values(free_cash_flow, present_value)
    print(f"Percentage Difference: {percentage_difference:.2f}%")

    implied_growth_rate = calculate_implied_growth_rate(free_cash_flow, market_cap, discount_rate, terminal_growth_rate)
    print(f"Current Implied Growth Rate: {implied_growth_rate:.2f}")

if __name__ == "__main__":
    main()
